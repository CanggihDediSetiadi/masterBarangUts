<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\Employee;
use App\Models\Position;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pageTitle = 'Barang List';
        $barang = Barang::all();
        $satuan = Satuan::all();

        return view('barang.index', compact('pageTitle', 'barang', 'satuan'));

    }

    public function create()
    {
        $pageTitle = 'Create Barang';
        // ELOQUENT
        $barang = Barang::all();
        $satuans = Satuan::all();
        return view('barang.create', compact('pageTitle', 'satuans'));
    }

    public function store(Request $request)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka'
            // Anda mungkin perlu menambahkan aturan validasi lain sesuai kebutuhan.
        ];
        $validator = Validator::make($request->all(), [
            'kode_barang' => 'required|unique:barang',
            'nama_barang' => 'required',
            'harga_barang' => 'required|numeric',
            'deskripsi_barang' => 'required',
            'satuan_barang_id' => 'required|numeric',
        ], $messages);

        // if ($validator->fails()) {
        //     return redirect()->back()->withErrors($validator)->withInput();
        // }
        // ELOQUENT
        $barang = new Barang;
        $barang->kode_barang = $request->kode_barang;
        $barang->nama_barang = $request->nama_barang;
        $barang->harga_barang = $request->harga_barang;
        $barang->deskripsi_barang = $request->deskripsi_barang;
        $barang->satuan_barang_id = $request->satuan_id;
        $barang->save();
        return redirect()->route('barang.index');
    }

    public function show(Barang $barang)
    {
        $pageTitle = 'deatail barang';
         // Fetch the barang with the given ID
        $satuan = Satuan::all(); // Assuming Satuan is another model for the dropdown
        return view('barang.show', compact('barang', 'satuan','pageTitle'));
    }

    public function edit($id)
{
    $pageTitle = 'Barang Edit';
    $barang = Barang::findOrFail($id); // Fetch the barang with the given ID
    $satuan = Satuan::all(); // Assuming Satuan is another model for the dropdown
    return view('barang.edit', [
        'barang' => $barang,
        'satuan' => $satuan,
        'pageTitle' =>$pageTitle
    ]);
}


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'email' => 'Isi :attribute dengan format yang benar',
            'numeric' => 'Isi :attribute dengan angka'
        ];
        $validator = Validator::make($request->all(), [
            'firstName' => 'required',
            'lastName' => 'required',
            'email' => 'required|email',
            'age' => 'required|numeric',
        ], $messages);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        // ELOQUENT
        $employee = Barang::find($id);
        $employee->firstname = $request->firstName;
        $employee->lastname = $request->lastName;
        $employee->email = $request->email;
        $employee->age = $request->age;
        $employee->position_id = $request->position;
        $employee->save();
        return redirect()->route('barang.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(barang $barang)
    {
        // ELOQUENT
        $barang->delete();
        return redirect()->route('barang.index');
    }
}

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ $barang->nama_barang }}</div>

                <div class="card-body">
                    <p><strong>Kode Barang:</strong> {{ $barang->kode_barang }}</p>
                    <p><strong>Harga Barang:</strong> Rp {{ number_format($barang->harga_barang, 2) }}</p>
                    <p><strong>Deskripsi Barang:</strong> {{ $barang->deskripsi_barang }}</p>
                    @if ($barang->satuan)
                        <p><strong>Satuan Barang:</strong> {{ $barang->satuan_barang_id }}</p>
                    @else
                        <p><strong>Satuan Barang:</strong> Satuan tidak tersedia.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
initial-scale=1.0">
    <title>Welcome</title>
    @vite('resources/sass/app.scss')
</head>

<body>
    <div class="container text-center my-5">
        <h1 class="mb-4">Selamat Datang di Website saya</h1>
        {{-- Contoh cara mereferensikan gambar di dalam file blade dengan
menggunakan pendekatan Vite --}}
        <img class="img-thumbnail" src="{{ Vite::asset('resources/images/Gambar slur.png') }}" alt="image">
        <div class="col-md-2 offset-md-5 mt-4">
            <div class="d-grid gap-2">
                <h4 class="mb-4">Nama: Canggih Dedi Setiadi</h4>
                <h4 class="mb-4">NIM: 1204220090</h4>
                <h4 class="mb-4">Jurusan: Sistem Informasi</h4>
                <h4 class="mb-4">Universitas: Telkom University Surabaya</h4>
                <a class="btn btn-dark" href="home">List Barang</a>
            </div>
        </div>
    </div>
    @vite('resources/js/app.js')
</body>

</html>

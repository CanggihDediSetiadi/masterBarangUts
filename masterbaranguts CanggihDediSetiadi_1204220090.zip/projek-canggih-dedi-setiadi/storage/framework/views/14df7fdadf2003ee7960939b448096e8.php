<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($barang->nama_barang); ?></div>

                <div class="card-body">
                    <p><strong>Kode Barang:</strong> <?php echo e($barang->kode_barang); ?></p>
                    <p><strong>Harga Barang:</strong> Rp <?php echo e(number_format($barang->harga_barang, 2)); ?></p>
                    <p><strong>Deskripsi Barang:</strong> <?php echo e($barang->deskripsi_barang); ?></p>
                    <?php if($barang->satuan): ?>
                        <p><strong>Satuan Barang:</strong> <?php echo e($barang->satuan_barang_id); ?></p>
                    <?php else: ?>
                        <p><strong>Satuan Barang:</strong> Satuan tidak tersedia.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHAQUILLE\Downloads\projek-canggih-dedi-setiadi\resources\views/barang/show.blade.php ENDPATH**/ ?>
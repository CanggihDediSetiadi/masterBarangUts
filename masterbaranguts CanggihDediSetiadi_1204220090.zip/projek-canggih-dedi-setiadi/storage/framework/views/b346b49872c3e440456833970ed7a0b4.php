<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Barang</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('barang.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="kode_barang">Kode Barang</label>
                                <input type="text" class="form-control" id="kode_barang" name="kode_barang" required>
                            </div>

                            <div class="form-group">
                                <label for="nama_barang">Nama Barang</label>
                                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
                            </div>

                            <div class="form-group">
                                <label for="harga_barang">Harga Barang</label>
                                <input type="text" class="form-control" id="harga_barang" name="harga_barang" required>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi_barang">Deskripsi Barang</label>
                                <textarea class="form-control" id="deskripsi_barang" name="deskripsi_barang" required></textarea>
                            </div>

                            <div class="form-group">
                                <label for="satuan_id">Satuan Barang</label>
                                <select class="form-control" id="satuan_id" name="satuan_id" required>
                                    <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($satuan->id); ?>"><?php echo e($satuan->nama_satuan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHAQUILLE\Downloads\projek-canggih-dedi-setiadi\resources\views/barang/create.blade.php ENDPATH**/ ?>
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('barangs')->insert([
            [
                'kode_barang' => 'kul1',
                'nama_barang' => 'Kulkas',
                'harga_barang'=> '100000',
                'deskripsi_barang' => 'Barang penyimpanan makanan',
                'satuan_barang_id' => 'Unit',
            ],
            [
                'kode_barang' => 'buk2',
                'nama_barang' => 'Buku Progammer',
                'harga_barang'=> '100000',
                'deskripsi_barang' => 'Buku buat belajar coding',
                'satuan_barang_id' => 'PCS',
            ],
            [
                'kode_barang' => 'key3',
                'nama_barang' => 'Keyboard',
                'harga_barang'=> '50000',
                'deskripsi_barang' => 'Untuk mengetik',
                'satuan_barang_id' => 'Unit',
            ],
        ]);
    }
}
